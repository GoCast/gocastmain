Placeholder for native extensions needed on qnx
